`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2026 11:41:05 PM
// Design Name: 
// Module Name: register_file
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module register_file #(
    parameter REGF_WIDTH = 16
)(
    input  logic                  clk,

    input  logic [1:0]            rs1,
    input  logic [1:0]            rs2,
    input  logic [1:0]            rd,

    input  logic [REGF_WIDTH-1:0] write_data,

    output logic [REGF_WIDTH-1:0] read_data1,
    output logic [REGF_WIDTH-1:0] read_data2
);

    // 4 registers, each REGF_WIDTH bits wide
    logic [REGF_WIDTH-1:0] register_file [0:3];


    // Initialize register file from binary file
    initial begin
        $readmemb("fib_rf.mem", register_file);

        // x0 must always remain zero
        register_file[0] = '0;
    end


    // First read port
    always_comb begin
        case (rs1)

            2'b00: read_data1 = '0;
            2'b01: read_data1 = register_file[1];
            2'b10: read_data1 = register_file[2];
            2'b11: read_data1 = register_file[3];

            default: read_data1 = '0;

        endcase
    end


    // Second read port
    always_comb begin
        case (rs2)

            2'b00: read_data2 = '0;
            2'b01: read_data2 = register_file[1];
            2'b10: read_data2 = register_file[2];
            2'b11: read_data2 = register_file[3];

            default: read_data2 = '0;

        endcase
    end


    // Write port
    always_ff @(posedge clk) begin
        case (rd)

            2'b00: register_file[0] <= '0;

            2'b01: register_file[1] <= write_data;

            2'b10: register_file[2] <= write_data;

            2'b11: register_file[3] <= write_data;

            default: register_file[0] <= '0;

        endcase
    end


    // Variables for register dump
    integer fd;
    integer i;


    // Open dump file and close it after 100 time units
    initial begin
        fd = $fopen("regfile.dump", "w");

        #100;

        $fclose(fd);
    end


    // Dump all register values on every positive clock edge
    always @(posedge clk) begin
        for (i = 0; i < 4; i = i + 1) begin
            $fdisplay(fd, register_file[i]);
        end
    end

endmodule 
