`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2026 11:32:35 PM
// Design Name: 
// Module Name: instruction_memory
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module instruction_memory #(
    parameter IMEM_DEPTH = 4
)(
    input  logic [$clog2(IMEM_DEPTH)-1:0] address,
    output logic [7:0]                    instruction
);

    // Instruction memory:
    // IMEM_DEPTH locations, each 8 bits wide
    logic [7:0] instruction_mem [0:IMEM_DEPTH-1];


    // Load instructions from binary file
    initial begin
        $readmemb( "fib_im.mem",instruction_mem);
    end


    // Combinational read
    always_comb begin
        instruction = instruction_mem[address];
    end

endmodule : instruction_memory

