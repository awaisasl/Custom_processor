`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/18/2026 03:17:42 AM
// Design Name: 
// Module Name: top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module top #(
    parameter IMEM_DEPTH = 4,
    parameter REGF_WIDTH = 16,
    parameter ALU_WIDTH  = 16,
    parameter PROG_VALUE = 3
)(
    input logic clk
);

    // ----------------------------------
    // Internal signals
    // ----------------------------------

    logic [1:0] pc;

    logic [7:0] instruction;

    logic [1:0] rd;
    logic [1:0] rs1;
    logic [1:0] rs2;
    logic [1:0] opcode;

    logic [REGF_WIDTH-1:0] operand1;
    logic [REGF_WIDTH-1:0] operand2;

    logic [ALU_WIDTH-1:0] alu_result;


    // ----------------------------------
    // Program Counter
    // ----------------------------------

    program_counter #(
        .PROG_VALUE(PROG_VALUE)
    ) pc_inst (
        .clk(clk),
        .pc(pc)
    );


    // ----------------------------------
    // Instruction Memory
    // ----------------------------------

    instruction_memory #(
        .IMEM_DEPTH(IMEM_DEPTH)
    ) imem_inst (
        .address(pc),
        .instruction(instruction)
    );


    // ----------------------------------
    // Instruction decoding
    // ----------------------------------

    assign rd     = instruction[7:6];
    assign rs2    = instruction[5:4];
    assign rs1    = instruction[3:2];
    assign opcode = instruction[1:0];


    // ----------------------------------
    // Register File
    // ----------------------------------

    register_file #(
        .REGF_WIDTH(REGF_WIDTH)
    ) regfile_inst (
        .clk(clk),

        .rs1(rs1),
        .rs2(rs2),

        .rd(rd),
        .write_data(alu_result),

        .read_data1(operand1),
        .read_data2(operand2)
    );


    // ----------------------------------
    // ALU
    // ----------------------------------

    alu #(
        .ALU_WIDTH(ALU_WIDTH)
    ) alu_inst (
        .operand1(operand1),
        .operand2(operand2),
        .opcode(opcode),
        .result(alu_result)
    );

endmodule : top