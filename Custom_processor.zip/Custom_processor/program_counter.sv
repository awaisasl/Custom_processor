`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2026 11:30:48 PM
// Design Name: 
// Module Name: program_counter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module program_counter #(
    parameter PROG_VALUE = 3
)(
    input logic clk,
    output logic [1:0] pc
);

    initial begin
        pc = '0;
    end

    always @(posedge clk) begin
        if (pc == PROG_VALUE)
            pc <= '0;
        else
            pc <= pc + 1'b1;
    end

endmodule
