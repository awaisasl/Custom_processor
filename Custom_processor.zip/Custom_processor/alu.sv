`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 07/17/2026 11:49:25 PM
// Design Name: 
// Module Name: alu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu #(
    parameter ALU_WIDTH = 16
)(
    input  logic [ALU_WIDTH-1:0] operand1,
    input  logic [ALU_WIDTH-1:0] operand2,
    input  logic [1:0]           opcode,
    output logic [ALU_WIDTH-1:0] result
);

    always_comb begin
        case (opcode)

            2'b00: result = operand1 + operand2; // ADD
            2'b01: result = operand1 - operand2; // SUB
            2'b10: result = operand1 & operand2; // AND
            2'b11: result = operand1 | operand2; // OR

            default: result = '0;

        endcase
    end

endmodule
